function EligeNum(){
    var a;
    a = prompt('Numero 1');
    a = Number(a);
    return a;
}

function ParImpar(){
    var num = EligeNum();
    if (num % 2 == 0){
        alert("El numero es par");
    }else {
        alert("El numero es impar");
    }
}