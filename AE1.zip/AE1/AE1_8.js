function PideNum() {
    var a;
    a=prompt('Elige un numero entre el 1 y el 12');
    a=Number(a);

    while (a > 12 || a <1) {
        alert("El numero no es valido, vuelve a elegir");
                a=prompt('Elige un numero entre 1 y 12');
                a=Number(a);
    }
    return a
}

function Dado(){
    var random = Math.round(Math.random() * 12 );
    var num = PideNum();
    if (num == random) {
        alert("Has adivinado el numero!");
    }else {
        alert("El numero es incorrecto, era el " + random);
    }
}

