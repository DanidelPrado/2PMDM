const ALERT_MESSAGE = "Soy el primer script";
nombre = navigator.appName;
version = navigator.appVersion;
alert(ALERT_MESSAGE + " y estoy funcionando sobre " + nombre + " " + version);