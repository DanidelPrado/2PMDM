var num = 15;
var total = 1;
for(i = 1; i <= num; i++){
    total = total * i;
}
console.log("El factorial del numero " + num + " es " + total);