function EligeNum(){
    var a;
    a = prompt('Numero 1');
    a = Number(a);
    return a;
}

function ValorAbsoluto(){
    var num = EligeNum();
    num = Math.abs(num);
    alert(num);
}